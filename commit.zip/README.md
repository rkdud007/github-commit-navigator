# Github Commit Navigator

Navigate through commit history on GitHub using arrow keys

![](.github/icon128.png)

## Features

- Navigate to the next commit using the right arrow key
- Navigate to the previous commit using the left arrow key
- Works on all GitHub repository pages
- Maintains scroll position when moving between commits
- Provides visual feedback when navigating
